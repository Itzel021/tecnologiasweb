<?php
    namespace Webtechnologies\Config;
    class App{
        public function __construct(){
            die('App config');
        }
    }
?>